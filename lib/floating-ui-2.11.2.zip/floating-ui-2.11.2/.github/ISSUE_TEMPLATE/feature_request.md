---
name: 🚀 Feature Request
about: I'd like to propose a new feature
title: ''
labels: '# ENHANCEMENT ✨, NEEDS: triage'
assignees: ''
---

## Feature description

<!-- What are you proposing? -->

## Why should this feature be part of the Popper's core?

<!-- Popper aims to be a lean positioning engine, additional features should be implemented in form of 3rd party modifiers, why should this feature get to the core? -->
